# Release Notes

### 🚀 v1.1.0

### Event Stream (SSE) & WebSocket Support
- Send **Event Stream (SSE)** requests with live, real-time event streaming
- Send **WebSocket** requests — connect, send, and receive messages in real time
- Requires Thunder Client CLI **1.27.14+**

### 🚀 v1.0.0

### Thunder Client for JetBrains is Here!
We’re excited to launch the **Beta of Thunder Client for JetBrains IDEs**! Bring the same lightweight, developer-first API experience you love from VS Code directly into your JetBrains workflow.

### ✨ Highlights

- Familiar UI — zero learning curve
- Lightweight and fast API client
- Support for Collections, Environments, and Scripting
- Code Snippets
- And more…

### 🎁 Beta Launch Offer
- Get a 1-month free trial for early adopters.
- Companies interested in trying the beta can [reach out to us](https://www.thunderclient.com/contact?utm_source=ext_github_jetbrains).